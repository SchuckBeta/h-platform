package com.oseasy.initiate.jobs;

public interface JobDetail {
	public void execute();
}
