/**
 * 
 */
package com.oseasy.initiate.common.persistence;

/**
 * DAO支持类实现

 * @version 2014-05-16
 */
public interface BaseDao {

}