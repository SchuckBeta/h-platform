package com.oseasy.initiate.common.utils.sms;

public class ISendParam {

}
