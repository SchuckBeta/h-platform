package com.oseasy.initiate.common.beanvalidator;

/**
 * 编辑Bena验证组

 */
public interface EditGroup {

}
