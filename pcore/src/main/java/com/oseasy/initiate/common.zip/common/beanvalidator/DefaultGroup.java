package com.oseasy.initiate.common.beanvalidator;

/**
 * 默认Bean验证组

 */
public interface DefaultGroup {

}
