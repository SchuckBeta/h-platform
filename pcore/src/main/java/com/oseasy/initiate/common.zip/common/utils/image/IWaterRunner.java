package com.oseasy.initiate.common.utils.image;

import com.oseasy.initiate.common.config.RstatusGroup;

/**
 * Created by Administrator on 2017/10/26 0026.
 */
public interface IWaterRunner {
    public RstatusGroup exec();//执行
}
