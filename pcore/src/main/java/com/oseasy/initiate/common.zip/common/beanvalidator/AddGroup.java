package com.oseasy.initiate.common.beanvalidator;

/**
 * 添加Bean验证组

 *
 */
public interface AddGroup {

}
