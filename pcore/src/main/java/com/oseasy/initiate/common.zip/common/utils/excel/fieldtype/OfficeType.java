/**
 * 
 */
package com.oseasy.initiate.common.utils.excel.fieldtype;

import com.oseasy.initiate.common.utils.StringUtil;
import com.oseasy.initiate.modules.sys.entity.Office;
import com.oseasy.initiate.modules.sys.utils.UserUtils;

/**
 * 字段类型转换


 */
public class OfficeType {

	/**
	 * 获取对象值（导入）
	 */
	public static Object getValue(String val) {
		for (Office e : UserUtils.getOfficeList()) {
			if (StringUtil.trimToEmpty(val).equals(e.getName())) {
				return e;
			}
		}
		return null;
	}

	/**
	 * 设置对象值（导出）
	 */
	public static String setValue(Object val) {
		if (val != null && ((Office)val).getName() != null) {
			return ((Office)val).getName();
		}
		return "";
	}
}
